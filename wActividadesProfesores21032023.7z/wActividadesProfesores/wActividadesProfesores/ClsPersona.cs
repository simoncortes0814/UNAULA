﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wActividadesProfesores
{
    public class ClsPersona
    {
        private string strnombre;
        public string asistir;

        
        public string Strnombre { get => strnombre; set => strnombre = value; }

        
        public ClsPersona ()
        {
            asistir = "";


            
        }
        
        public string Asistir(string asistir)
        {
            Console.WriteLine("Asiste a la escuela");
            return asistir;
            
        }
    }
}
