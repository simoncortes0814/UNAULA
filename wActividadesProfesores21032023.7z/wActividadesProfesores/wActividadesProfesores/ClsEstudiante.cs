﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wActividadesProfesores
{
    class ClsEstudiante : ClsPersona
    {
        private int intCalificacion;
        public string estudiar;
        public int IntCalificacion { get => intCalificacion; set => intCalificacion = value; }

        public ClsEstudiante()
        {
            intCalificacion = 0;
            estudiar = "";
            
        }
       

    }
}
