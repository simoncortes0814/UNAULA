﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wActividadesProfesores
{
    public class ClsProfesor : ClsPersona
    {
       
        private double dlbSueldo;
        public string enseñar;

        public double DlbSueldo { get => dlbSueldo; set => dlbSueldo = value; }
        public ClsProfesor()
        {
            enseñar = "";
        }
        
        public string Enseñar()
        {
            Console.WriteLine(Strnombre + " Está enseñando en la escuela.");
            return enseñar;
        }
    }
}
