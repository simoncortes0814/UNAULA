﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// Fecha: 21 de Marzo de 2023
/// Nombre : Angie Moreno Betancur - Simón Cortés Lotero
/// Programa : Profesores Estudiantes
/// </summary>
namespace wActividadesProfesores
{
    public partial class frmEstudiantesProfesores : Form
    {
        public frmEstudiantesProfesores()
        {
            InitializeComponent();
            txtSueldo.Text = "0";
            txtCalificacion.Text = "0";
        }

        

        private void btnMostrarDatos_Click(object sender, EventArgs e)
        {
           
            try
            {

                
                ClsEstudiante Estudiante = new ClsEstudiante();
                ClsProfesor Profesor = new ClsProfesor();
                ClsPersona Persona = new ClsPersona();
                Estudiante.IntCalificacion = Convert.ToInt16(txtCalificacion.Text);
                Persona.Strnombre = txtNombre.Text;
                Profesor.DlbSueldo = double.Parse(txtSueldo.Text);
                
               
                if (chkProfesor.Checked==true )
                {
                    
                    MessageBox.Show("Nombre:" + txtNombre.Text + "\n Su sueldo es: $" + txtSueldo.Text + "\n" + txtNombre.Text + " Asiste a la escuela" + "\n" +  txtNombre.Text  + " Está enseñando en la escuela");
                   
                }
                else if (chkEstudiante.Checked==true)
                {
                    MessageBox.Show("Nombre: " + txtNombre.Text + "\n Su calificación es: " + txtCalificacion.Text + "\n" + txtNombre.Text + " Asiste a la escuela" + "\n" + txtNombre.Text + " Está estudiando");
                }

            }
            catch (Exception ex)    
            {

                MessageBox.Show("" + ex.Message);

            }



        }

        private void frmEstudiantesProfesores_Load(object sender, EventArgs e)
        {

        }

        private void btnCapturarDatos_Click(object sender, EventArgs e)
        {
            txtNombre.Text = "";
            txtCalificacion.Text = "";
            txtSueldo.Text = "";
        }
    }
}
