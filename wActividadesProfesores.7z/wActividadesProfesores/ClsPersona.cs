﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wActividadesProfesores
{
    public class ClsPersona
    {
        private string strnombre;
        public string strasistir;

        
        public string Strnombre { get => strnombre; set => strnombre = value; }

        
        public ClsPersona ()
        {
            strasistir = "";


            
        }
        
        public string Asistir(string strasistir)
        {
            Console.WriteLine("Asiste a la escuela");
            return strasistir;
            
        }
    }
}
