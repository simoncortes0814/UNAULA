﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cuadrado
{
    class Program
    {
        static void Main(string[] args)
        {
            // Desarrollar una clase que represente un Cuadrado y tenga los siguientes métodos: cargar el valor de su lado, imprimir su perímetro y su superficie.

            ClsCuadrado Cuadrado = new ClsCuadrado();

            Console.WriteLine("Ingrese por favor el lado del cuadrado ");
            Cuadrado.lado = int.Parse(Console.ReadLine());
            Cuadrado.PerimetroCuadrado();
            Cuadrado.SuperficieCuadrado();
            Console.ReadKey();
        }
    }

}
